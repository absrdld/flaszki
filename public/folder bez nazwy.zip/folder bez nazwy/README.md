# Obrazy do Fiszek

Tutaj umieść pliki z obrazami.
Nazwy plików muszą odpowiadać nazwie w pliku `src/data/artworks.ts` (kolumna `filename`).
Format: `.png`

Przykłady:
- `Portret_małżonków_Arnolfinich-Jan_van_Eyck-century-15-style-Renesans.png`
- `Bitwa_pod_San_Romano-Paolo_Uccello-century-15-style-Renesans.png`